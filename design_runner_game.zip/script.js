// JS placeholder
function startGame() {}
function restartGame() {}